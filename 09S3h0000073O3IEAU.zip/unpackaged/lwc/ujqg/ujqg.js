import { LightningElement } from 'lwc';

export default class Ujqg extends LightningElement {}